let myNum1 = 1000.324423342;
let myNum2 = "100";
console.log(myNum1);
console.log(myNum2);